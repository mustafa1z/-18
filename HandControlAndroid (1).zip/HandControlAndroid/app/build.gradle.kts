plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.handcontrol.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.handcontrol.ai2"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("stable") {
            storeFile = file("stable.jks")
            storePassword = "android"
            keyAlias = "stable"
            keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
        debug { signingConfig = signingConfigs.getByName("stable") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-service:2.8.6")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// تنزيل نموذج تتبع اليد تلقائياً عند أول بناء (يحتاج إنترنت)
val modelFile = file("src/main/assets/hand_landmarker.task")
val downloadModel by tasks.registering {
    outputs.file(modelFile)
    onlyIf { !modelFile.exists() }
    doLast {
        modelFile.parentFile.mkdirs()
        val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
        java.net.URL(url).openStream().use { i -> modelFile.outputStream().use { o -> i.copyTo(o) } }
    }
}
tasks.named("preBuild") { dependsOn(downloadModel) }
