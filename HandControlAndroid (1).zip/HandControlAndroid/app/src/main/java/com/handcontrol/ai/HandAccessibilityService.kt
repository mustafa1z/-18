package com.handcontrol.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** ينفّذ النقر/السحب/الرجوع الحقيقي على النظام ويرسم المؤشر فوق كل التطبيقات. */
class HandAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: HandAccessibilityService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var cursor: CursorView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = CursorView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        cursor = v
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        cursor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cursor = null
        super.onDestroy()
    }

    fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    fun setCursor(x: Float, y: Float, visible: Boolean, idle: Boolean, pressed: Boolean) {
        main.post { cursor?.update(x, y, visible, idle, pressed) }
    }

    fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y); lineTo(x + 0.5f, y) }
        dispatch(p, 70)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durMs: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatch(p, durMs.coerceIn(80, 1200))
    }

    fun swipeDir(d: String) {
        val (w, h) = screenSize(); val cx = w / 2f; val cy = h / 2f
        when (d) {
            "right" -> swipe(w * 0.2f, cy, w * 0.8f, cy, 250)
            "left" -> swipe(w * 0.8f, cy, w * 0.2f, cy, 250)
            "up" -> swipe(cx, h * 0.3f, cx, h * 0.7f, 250)     // تمرير لأعلى
            "down" -> swipe(cx, h * 0.7f, cx, h * 0.3f, 250)   // تمرير لأسفل
        }
    }

    fun launchPackage(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        main.post { try { startActivity(i) } catch (_: Exception) {} }
        return true
    }

    /** يضغط على عنصر على الشاشة يحتوي هذا النص. */
    fun clickByText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    fun openIntent(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        main.post { try { startActivity(i) } catch (_: Exception) {} }
    }

    fun notifications() { main.post { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) } }
    fun quickSettings() { main.post { performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) } }
    fun screenshot() { if (Build.VERSION.SDK_INT >= 28) main.post { performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) } }
    fun lockScreen() { if (Build.VERSION.SDK_INT >= 28) main.post { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) } }

    /** يضغط على عنصر وصفه أو معرّفه يحتوي إحدى الكلمات (مثل زر الكاميرا). */
    fun clickByDesc(keys: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        fun walk(n: AccessibilityNodeInfo?): Boolean {
            if (n == null) return false
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            val id = (n.viewIdResourceName ?: "").lowercase()
            if (keys.any { d.contains(it) || id.contains(it) }) {
                var x: AccessibilityNodeInfo? = n
                while (x != null && !x.isClickable) x = x.parent
                if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            for (i in 0 until n.childCount) if (walk(n.getChild(i))) return true
            return false
        }
        return walk(root)
    }

    fun typeText(t: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /** يلتقط صورة داخل تطبيق الكاميرا المفتوح. */
    fun shutter() {
        val ok = clickByDesc(listOf("shutter", "capture", "take photo", "take picture", "التقاط", "شاتر", "غالق"))
        if (!ok) { val (w, h) = screenSize(); tap(w / 2f, h * 0.87f) }
    }

    /** يغلق تطبيقاً عبر صفحة معلومات التطبيق ← «إيقاف إجباري». */
    fun forceStop(pkg: String) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
        openIntent(i)
        val stopTexts = listOf("إيقاف إجباري", "فرض الإيقاف", "فرض الإنهاء", "إيقاف", "force stop", "force close")
        val okTexts = listOf("موافق", "حسنًا", "حسنا", "إيقاف إجباري", "فرض الإيقاف", "force stop", "ok")
        main.postDelayed({
            var done = false
            for (t in stopTexts) { if (clickByText(t)) { done = true; break } }
            if (done) {
                main.postDelayed({
                    for (t in okTexts) { if (clickByText(t)) break }
                    main.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 800)
                }, 900)
            } else {
                main.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 300)
            }
        }, 1300)
    }

    fun back() { main.post { performGlobalAction(GLOBAL_ACTION_BACK) } }
    fun home() { main.post { performGlobalAction(GLOBAL_ACTION_HOME) } }
    fun recents() { main.post { performGlobalAction(GLOBAL_ACTION_RECENTS) } }

    private fun dispatch(path: Path, dur: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        main.post { dispatchGesture(g, null, null) }
    }

    private class CursorView(c: Context) : View(c) {
        private var cx = 0f; private var cy = 0f
        private var vis = false; private var idle = false; private var pressed = false
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

        fun update(x: Float, y: Float, v: Boolean, i: Boolean, p: Boolean) {
            cx = x; cy = y; vis = v; idle = i; pressed = p; invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            if (!vis) return
            val col = if (pressed) Color.parseColor("#F59E0B") else Color.parseColor("#10B981")
            val a = if (idle) 70 else 255
            val r = if (pressed) 30f else 44f
            fill.color = col; fill.alpha = if (idle) 20 else 70
            ring.color = col; ring.alpha = a
            canvas.drawCircle(cx, cy, r, fill)
            canvas.drawCircle(cx, cy, r, ring)
            fill.alpha = a
            canvas.drawCircle(cx, cy, 6f, fill)
        }
    }
}
