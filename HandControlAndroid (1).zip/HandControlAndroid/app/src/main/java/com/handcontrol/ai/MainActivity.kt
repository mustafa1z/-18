package com.handcontrol.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnStart: Button
    private lateinit var btnVoice: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#070D14"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tv(t: String, sz: Float, c: String, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sz; setTextColor(Color.parseColor(c)); gravity = Gravity.START
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, pad / 2)
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }
        }

        col.addView(tv("✋ HandControl", 28f, "#10B981", true))
        col.addView(tv("تحكم حقيقي بهاتفك بحركة اليد أمام الكاميرا الأمامية.", 14f, "#8AA0B4"))
        status = tv("", 14f, "#FDE68A")
        col.addView(status)
        col.addView(btn("١) السماح بالكاميرا والإشعارات") { askPerms() })
        col.addView(btn("٢) تفعيل خدمة إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        btnStart = btn("٣) تشغيل التحكم") { toggle() }
        col.addView(btnStart)
        btnVoice = btn("٤) تشغيل الأوامر الصوتية 🎤") { toggleVoice() }
        col.addView(btnVoice)
        col.addView(btn("٥) عرض التطبيقات التي يتعرف عليها") { showApps() })
        col.addView(tv(
            "\nالإيماءات:\n" +
            "☝️ سبابة فقط = تحريك المؤشر\n" +
            "✌️ إصبعان = نقر (افتح التطبيق)\n" +
            "🤟 ثلاثة أصابع + تحريك اليد = قلب الصفحة\n" +
            "🤏 قرصة سريعة = نقر / قرصة + حركة = سحب\n" +
            "👊 قبضة + حركة لأعلى/أسفل = تمرير\n" +
            "🤙 الخنصر فقط = رجوع    👍 الشاشة الرئيسية\n" +
            "✋ كف مفتوح = إيقاف مؤقت\n\n" +
            "🎤 الأوامر الصوتية (الزر ٤):\n" +
            "«افتح [أي تطبيق]» / «اغلق [أي تطبيق]»\n" +
            "«التقط صورة» / «افتح الكاميرا وخذ صورة»\n" +
            "«اتصل بـ [اسم]» / «ابحث عن ...» / «اكتب ...»\n" +
            "«شغل الفلاش» / «ارفع الصوت» / «لقطة شاشة» / «الإشعارات»\n" +
            "«يمين» «يسار» = قلب الصفحة\n" +
            "«فوق» «تحت» = تمرير\n" +
            "«رجوع» «الرئيسية» «الأخيرة»\n" +
            "«اضغط على [كلمة على الشاشة]»\n" +
            "«إيقاف» = إيقاف الأوامر الصوتية\n\n" +
            "ملاحظة: على أندرويد ١٣+ إن كان خيار خدمة إمكانية الوصول رمادياً: " +
            "الإعدادات ← التطبيقات ← HandControl ← ⋮ ← «السماح بالإعدادات المقيدة»، ثم أعد المحاولة.",
            13f, "#CBD5E1"))
        setContentView(ScrollView(this).apply { addView(col); setBackgroundColor(Color.parseColor("#070D14")) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun camOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun accOk() = HandAccessibilityService.instance != null

    private fun refresh() {
        status.text = "الكاميرا: " + (if (camOk()) "✅" else "❌") +
            "    إمكانية الوصول: " + (if (accOk()) "✅" else "❌") +
            "    التحكم: " + (if (CameraHandService.running) "🟢 يعمل" else "⚪ متوقف") +
            "    الصوت: " + (if (VoiceService.running) "🟢" else "⚪")
        btnStart.text = if (CameraHandService.running) "٣) إيقاف التحكم" else "٣) تشغيل التحكم"
        btnVoice.text = if (VoiceService.running) "٤) إيقاف الأوامر الصوتية" else "٤) تشغيل الأوامر الصوتية 🎤"
    }

    private fun askPerms() {
        val p = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refresh()
    }

    private fun showApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val names = pm.queryIntentActivities(q, 0).map { it.loadLabel(pm).toString() }.distinct().sorted()
        android.app.AlertDialog.Builder(this)
            .setTitle("التطبيقات المقروءة (" + names.size + ")")
            .setMessage(names.joinToString("\n"))
            .setPositiveButton("إغلاق", null).show()
    }

    private fun toggleVoice() {
        if (VoiceService.running) {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            btnVoice.postDelayed({ refresh() }, 500); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askPerms(); return }
        if (!accOk()) { status.text = "فعّل خدمة HandControl من إعدادات إمكانية الوصول أولاً"; return }
        ContextCompat.startForegroundService(this, Intent(this, VoiceService::class.java))
        btnVoice.postDelayed({ refresh() }, 800)
        moveTaskToBack(true)
    }

    private fun toggle() {
        if (CameraHandService.running) {
            startService(Intent(this, CameraHandService::class.java).setAction(CameraHandService.ACTION_STOP))
            btnStart.postDelayed({ refresh() }, 500); return
        }
        if (!camOk()) { askPerms(); return }
        if (!accOk()) { status.text = "فعّل خدمة HandControl من إعدادات إمكانية الوصول أولاً"; return }
        ContextCompat.startForegroundService(this, Intent(this, CameraHandService::class.java))
        btnStart.postDelayed({ refresh() }, 800)
        // أرجع للشاشة الرئيسية لتجربة التحكم
        moveTaskToBack(true)
    }
}
