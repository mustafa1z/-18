package com.handcontrol.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.SearchManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** أوامر صوتية بالعربي تنفّذ فوراً: فتح/إغلاق أي تطبيق، تصوير، اتصال، بحث، صوت، فلاش ... */
class VoiceService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.handcontrol.ai.VSTOP"
        private const val CH = "handcontrol_voice"
    }

    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var torchOn = false
    @Volatile private var lastFail: String? = null
    private var lastAlt: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("⚠️ خدمة التعرف على الصوت غير متوفرة في هاتفك"); stopSelf(); return
        }
        running = true
        toast("🎤 الأوامر الصوتية تعمل — قل مثلاً: افتح تلكرام")
        h.post { listen() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        super.onDestroy()
    }

    private fun toast(t: String) = h.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() }

    private fun listen() {
        if (!running) return
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this)
            rec?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                    lastFail = null
                    var done = false
                    for (t in list) { if (handle(t)) { done = true; break } }
                    if (!done && list.isNotEmpty()) toast(lastFail ?: "❓ سمعت: ${list[0]}")
                    h.postDelayed({ listen() }, 250)
                }
                override fun onError(e: Int) {
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-IQ")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf("en-US"))
        }
        try { rec?.startListening(i) } catch (_: Exception) { h.postDelayed({ listen() }, 800) }
    }

    // ───────────── أدوات النص ─────────────
    private fun norm(s: String) = s.lowercase()
        .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه').trim()

    private fun has(t: String, vararg w: String) = w.any { t == norm(it) || t.split(" ").contains(norm(it)) }
    private fun anyIn(t: String, vararg p: String) = p.any { t.contains(norm(it)) }

    private val a2l = mapOf(
        'ا' to "a", 'ب' to "b", 'ت' to "t", 'ث' to "t", 'ج' to "g", 'ح' to "h", 'خ' to "x", 'د' to "d",
        'ذ' to "d", 'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "x", 'ص' to "s", 'ض' to "d", 'ط' to "t",
        'ظ' to "z", 'ع' to "a", 'غ' to "g", 'ف' to "f", 'ق' to "k", 'ك' to "k", 'ل' to "l", 'م' to "m",
        'ن' to "n", 'ه' to "h", 'و' to "w", 'ي' to "y", 'ء' to "", 'ئ' to "", 'ؤ' to "", 'پ' to "b",
        'چ' to "x", 'ڤ' to "f", 'گ' to "g"
    )

    private fun translit(ar: String) = ar.map { a2l[it] ?: it.toString() }.joinToString("")

    /** هيكل صوتي: يحذف أحرف العلة ويوحّد الحروف المتقاربة النطق (k=q=c ، t=d ، s=z ، g=j ، b=p) */
    private fun skel(s0: String): String {
        val x = s0.lowercase().replace("sh", "x").replace("kh", "x").replace("ch", "x")
            .replace("th", "t").replace("gh", "g").replace("ph", "f").replace("ck", "k")
        val sb = StringBuilder()
        for (i in x.indices) {
            val c = x[i]
            val nx = if (i + 1 < x.length) x[i + 1] else ' '
            val m = when (c) {
                'c' -> if (nx == 'e' || nx == 'i' || nx == 'y') 's' else 'k'
                'q' -> 'k'; 'v' -> 'f'; 'p' -> 'b'; 'z' -> 's'; 'd' -> 't'; 'j' -> 'g'
                else -> c
            }
            if (m in "aeiouyhw") continue
            if (m.isLetter() && (sb.isEmpty() || sb.last() != m)) sb.append(m)
        }
        return sb.toString()
    }

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun sim(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        return if (m == 0) 0.0 else 1.0 - lev(a, b).toDouble() / m
    }

    private fun score(spoken: String, label: String): Double {
        val l = norm(label)
        if (l.isEmpty() || spoken.isEmpty()) return 0.0
        if (l == spoken) return 1.0
        if ((l.contains(spoken) && spoken.length >= 3) || (spoken.contains(l) && l.length >= 3)) return 0.95
        val sk = skel(translit(spoken))
        var best = sim(spoken, l)
        val words = label.split(Regex("[\\s\\-_.]+")).filter { it.isNotEmpty() }
        val extra = 0.04 * (words.size - 1)          // تفضيل الاسم الأقصر (يوتيوب أصلي قبل يوتيوب ميوزك)
        val whole = skel(label)
        if (sk.length >= 2 && whole.length >= 2) {
            best = maxOf(best, sim(sk, whole) * 0.99)
            if (sk.length >= 3 && whole.startsWith(sk)) best = maxOf(best, 0.86)   // اسم مختصر مثل «انستا»
        }
        for (w in words) {
            val k = skel(w)
            if (k.length >= 2 && sk.length >= 2) {
                best = maxOf(best, sim(sk, k) * 0.98 - extra)
                if (sk.length >= 3 && k.startsWith(sk)) best = maxOf(best, 0.84 - extra)
            }
        }
        return best
    }

    // ───────────── البحث عن التطبيقات ─────────────
    private val aliases = listOf(
        listOf("ببجي", "بابجي", "ببجي موبايل") to listOf("pubg"),
        listOf("باينانس", "بينانس", "بايننس") to listOf("binance"),
        listOf("ديسكورد", "ديسكرد") to listOf("discord"),
        listOf("زوم") to listOf("zoom"),
        listOf("بنترست", "بنتريست", "بينترست") to listOf("pinterest"),
        listOf("كلود") to listOf("claude"),
        listOf("كلاس روم", "كلاسروم") to listOf("classroom"),
        listOf("اوسكار", "اوسكار تي في") to listOf("oscar"),
        listOf("سوبر في بي ان", "سوبر vpn") to listOf("supervpn"),
        listOf("زي ارشيفر", "ارشيفر") to listOf("zarchiver"),
        listOf("واتساب بزنس", "واتس اب بزنس", "واتساب بيزنس", "واتس بزنس") to listOf("=com.whatsapp.w4b"),
        listOf("واتساب", "واتس اب", "واتس", "وتساب") to listOf("=com.whatsapp"),
        listOf("يوتيوب ميوزك", "يوتيوب موسيقي", "يوتيوب موسيقى", "يوتيوب الاغاني", "يوتيوب اغاني", "يوتيوب مزيك", "ميوزك") to listOf("=com.google.android.apps.youtube.music"),
        listOf("يوتيوب كيدز", "يوتيوب اطفال") to listOf("=com.google.android.apps.youtube.kids"),
        listOf("يوتيوب", "يوتوب") to listOf("=com.google.android.youtube"),
        listOf("تلكرام", "تليجرام", "تلغرام", "تيليجرام") to listOf("telegram"),
        listOf("انستا", "انستغرام", "انستقرام", "انستجرام") to listOf("instagram"),
        listOf("فيسبوك", "فيس بوك", "فيس") to listOf("com.facebook.katana"),
        listOf("ماسنجر") to listOf("com.facebook.orca"),
        listOf("تيك توك", "تيكتوك") to listOf("musically", "trill", "tiktok"),
        listOf("كاميرا", "الكاميرا") to listOf("camera"),
        listOf("اعدادات", "الاعدادات") to listOf("com.android.settings"),
        listOf("كروم", "متصفح", "المتصفح") to listOf("com.android.chrome"),
        listOf("صور", "الصور", "معرض", "المعرض") to listOf("gallery", "photos"),
        listOf("هاتف", "اتصال", "اتصالات", "الهاتف") to listOf("dialer", "com.android.phone"),
        listOf("رسائل", "الرسائل") to listOf("messaging", "mms"),
        listOf("حاسبه", "الحاسبه", "اله حاسبه") to listOf("calculator"),
        listOf("خرائط", "الخرائط") to listOf("com.google.android.apps.maps"),
        listOf("ساعه", "الساعه", "منبه", "المنبه") to listOf("deskclock", "clock"),
        listOf("سناب", "سنابشات", "سناب شات") to listOf("snapchat"),
        listOf("جيميل", "بريد") to listOf("com.google.android.gm"),
        listOf("متجر", "بلاي ستور", "جوجل بلاي", "المتجر") to listOf("com.android.vending"),
        listOf("سبوتيفاي") to listOf("spotify"),
        listOf("تويتر", "اكس") to listOf("com.twitter")
    )

    private fun installedApps(): List<Pair<String, String>> {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinctBy { it.first }
    }

    private var cands: List<Pair<String, String>> = emptyList()
    private var pending: List<Pair<String, String>>? = null
    private var pendingName = ""
    private var pendingT = 0L
    private fun prefs() = getSharedPreferences("voice", MODE_PRIVATE)
    private val genericSeg = setOf("android", "app", "apps", "mobile", "client", "main", "launcher", "lite", "free")

    /** يحوّل ما قلته إلى (اسم الحزمة، اسم التطبيق) لأي تطبيق مثبّت. */
    private fun resolveApp(spokenRaw: String): Pair<String, String>? {
        lastAlt = null; cands = emptyList()
        val spoken = norm(spokenRaw)
        if (spoken.isEmpty()) return null
        val apps = installedApps()
        // ١) اختيارك السابق عند التشابه
        prefs().getString("alias_$spoken", null)?.let { pkg -> apps.firstOrNull { it.first == pkg }?.let { return it } }
        // ٢) أسماء معروفة
        for ((names, keys) in aliases) {
            if (names.any { val n = norm(it); spoken == n || (" $spoken ").contains(" $n ") }) {
                val hit = apps.firstOrNull { (pkg, label) ->
                    keys.any { k -> if (k.startsWith("=")) pkg == k.substring(1) else (pkg.lowercase().contains(k) || label.lowercase().contains(k)) }
                }
                if (hit != null) return hit
            }
        }
        // ٣) مطابقة صوتية مع اسم التطبيق (عربي أو إنجليزي) واسم الحزمة
        val scored = apps.map { a ->
            val seg = a.first.substringAfterLast('.')
            val ps = if (seg.lowercase() in genericSeg) 0.0 else score(spoken, seg) * 0.96
            a to maxOf(score(spoken, a.second), ps)
        }.sortedByDescending { it.second }
        val top = scored.firstOrNull() ?: return null
        if (top.second < 0.7) return null
        val close = scored.filter { top.second - it.second < 0.05 && it.second >= 0.75 }.take(3).map { it.first }
        cands = if (close.size > 1) close else emptyList()
        return top.first
    }

    // ───────────── أوامر متنوعة ─────────────
    private fun setTorch(on: Boolean) {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            cm.setTorchMode(id, on); torchOn = on
        } catch (_: Exception) {}
    }

    private fun volume(dir: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun asciiDigits(s: String) = s.mapNotNull { val d = Character.digit(it, 10); if (d >= 0) d.toString() else null }.joinToString("")

    private fun lookupContact(who: String): String? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val target = norm(who)
        var best: String? = null; var bs = 0.0
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = norm(c.getString(0) ?: "")
                    val s = if (n == target) 1.0 else if (n.contains(target) || target.contains(n)) 0.9 else sim(skel(translit(target)), skel(translit(n))) * 0.85
                    if (s > bs) { bs = s; best = c.getString(1) }
                }
            }
        } catch (_: Exception) {}
        return if (bs >= 0.7) best else null
    }

    private fun doCall(acc: HandAccessibilityService, whoRaw: String) {
        val digits = asciiDigits(whoRaw)
        val cands = listOf(whoRaw, whoRaw.removePrefix("ب").removePrefix("ب"))
        val number = if (digits.length >= 5) digits else cands.firstNotNullOfOrNull { lookupContact(it) }
        if (number == null) { toast("❌ ما لقيت جهة اتصال: $whoRaw"); return }
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        acc.openIntent(Intent(action, Uri.parse("tel:" + number.replace(" ", ""))))
        toast("📞 اتصال بـ $whoRaw")
    }

    private val openRe = Regex("^(افتح|افتحي|افتحلي|شغل|روح|open)(\\s+(علي|على|الي|الى|لي))?\\s+(.+)$")
    private val closeRe = Regex("^(اغلق|اغلقي|سكر|اقفل|انهي|اقتل|close|kill)(\\s+(التطبيق|تطبيق))?(\\s+(.+))?$")
    private val callRe = Regex("^(اتصل|كلم|كلمني|دق|call)\\s+(.+)$")
    private val searchRe = Regex("^(ابحث|دور|فتش|search)(\\s+(عن|علي|على|في))?\\s+(.+)$")
    private val typeRe = Regex("^(اكتب|اكتبلي|type)\\s+(.+)$")
    private val clickRe = Regex("^(اضغط|انقر|كبس|دوس|click)(\\s+(علي|على))?\\s+(.+)$")
    private val photoRe = Regex("(خذ|اخذ|التقط|صور|اعمل|سوي)\\s*(لي\\s*)?(صوره|سيلفي)")

    private fun rest(raw: String, m: MatchResult, group: Int): String {
        val g = m.groups[group] ?: return ""
        return raw.substring(g.range.first, g.range.last + 1).trim()
    }

    private fun handle(text: String): Boolean {
        val acc = HandAccessibilityService.instance ?: return false
        val raw = text.replace(Regex("[\\u064B-\\u0652\\u0640]"), "").trim()
        val t = norm(raw)
        if (t.isEmpty()) return false
        fun say(s: String) = toast("🎤 $s")

        // ── اختيار بين تطبيقين متشابهين ──
        pending?.let { p ->
            if (System.currentTimeMillis() - pendingT > 15000) pending = null
            else {
                val idx = when {
                    has(t, "واحد", "الاول", "اول", "1", "one") -> 0
                    has(t, "اثنين", "اتنين", "الثاني", "ثاني", "2", "two") -> 1
                    has(t, "ثلاثه", "تلاته", "الثالث", "ثالث", "3", "three") -> 2
                    else -> -1
                }
                if (idx in p.indices) {
                    prefs().edit().putString("alias_$pendingName", p[idx].first).apply()
                    acc.launchPackage(p[idx].first); say("✅ فتح: ${p[idx].second}")
                    pending = null; return true
                }
            }
        }

        // ── أوامر النظام ──
        val short = t.split(" ").size <= 3
        if (anyIn(t, "الفلاش", "فلاش", "الكشاف", "الفانوس", "الضوء")) {
            val off = anyIn(t, "اطفي", "اطفئ", "طفي", "اغلق", "سكر", "ايقاف", "وقف")
            setTorch(!off); say(if (off) "إطفاء الفلاش" else "تشغيل الفلاش"); return true
        }
        if (anyIn(t, "الصوت", "صوت")) {
            when {
                anyIn(t, "ارفع", "زيد", "علي", "اعلي", "زود") -> { volume(AudioManager.ADJUST_RAISE); say("رفع الصوت"); return true }
                anyIn(t, "خفض", "نزل", "وطي", "قلل", "اخفض") -> { volume(AudioManager.ADJUST_LOWER); say("خفض الصوت"); return true }
                anyIn(t, "اكتم", "كتم") -> { volume(AudioManager.ADJUST_MUTE); say("كتم"); return true }
            }
        }
        if (anyIn(t, "لقطه شاشه", "لقطه الشاشه", "صور الشاشه", "سكرين شوت", "screenshot")) { acc.screenshot(); say("لقطة شاشة"); return true }
        if (anyIn(t, "الاعدادات السريعه", "اعدادات سريعه")) { acc.quickSettings(); say("الإعدادات السريعة"); return true }
        if (anyIn(t, "الاشعارات", "الاشعار")) { acc.notifications(); say("الإشعارات"); return true }
        if (anyIn(t, "اقفل الشاشه", "قفل الشاشه", "اطفي الشاشه", "قفل الجهاز")) { acc.lockScreen(); say("قفل الشاشة"); return true }
        if (short && has(t, "رجوع", "ارجع", "للخلف", "back")) { acc.back(); say("رجوع"); return true }
        if (short && has(t, "رئيسيه", "الرئيسيه", "البيت", "هوم", "home")) { acc.home(); say("الرئيسية"); return true }
        if (short && has(t, "الاخيره", "اخيره", "recents")) { acc.recents(); say("التطبيقات الأخيرة"); return true }
        if (short && has(t, "يمين", "لليمين", "right")) { acc.swipeDir("right"); say("يمين ➡️"); return true }
        if (short && has(t, "يسار", "لليسار", "left")) { acc.swipeDir("left"); say("يسار ⬅️"); return true }
        if (short && has(t, "فوق", "لفوق", "اعلي", "اعلا", "اطلع", "up")) { acc.swipeDir("up"); say("فوق ⬆️"); return true }
        if (short && has(t, "تحت", "لتحت", "اسفل", "انزل", "down")) { acc.swipeDir("down"); say("تحت ⬇️"); return true }
        if (short && has(t, "ايقاف", "وقف", "اوقف", "stop")) { say("تم إيقاف الأوامر الصوتية"); stopSelf(); return true }

        // ── تصوير ──
        if (photoRe.containsMatchIn(t) || t == "صور" || t == "التقط") {
            if (anyIn(t, "كاميرا", "افتح")) {
                val cam = resolveApp("كاميرا")
                if (cam != null) { acc.launchPackage(cam.first); h.postDelayed({ acc.shutter() }, 2300) }
                else toast("❌ ما لقيت تطبيق الكاميرا")
            } else acc.shutter()
            say("📸 تصوير"); return true
        }

        // ── إغلاق تطبيق ──
        closeRe.find(t)?.let { m ->
            val name = rest(raw, m, 5)
            val nn = norm(name)
            val current = nn.isEmpty() || nn in listOf("هذا", "هاذا", "هذا التطبيق", "الحالي", "هذاك")
            val target: Pair<String, String>? = if (current) {
                val p = acc.currentPackage()
                if (p == null || p == packageName) null else p to p
            } else resolveApp(name)
            if (target == null) { lastFail = "❌ ما لقيت تطبيق لإغلاقه: $name"; return false }
            acc.forceStop(target.first); say("🔴 إغلاق: ${target.second}"); return true
        }

        // ── اتصال ──
        callRe.find(t)?.let { m -> doCall(acc, rest(raw, m, 2)); return true }

        // ── بحث ──
        searchRe.find(t)?.let { m ->
            val q = rest(raw, m, 4)
            acc.openIntent(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
            say("🔎 بحث: $q"); return true
        }

        // ── كتابة ──
        typeRe.find(t)?.let { m ->
            val s = rest(raw, m, 2)
            if (!acc.typeText(s)) toast("❌ اضغط على خانة الكتابة أولاً")
            else say("✍️ $s")
            return true
        }

        // ── فتح تطبيق ──
        openRe.find(t)?.let { m ->
            val name = rest(raw, m, 4)
            val app = resolveApp(name)
            if (app == null) { lastFail = "❌ ما لقيت تطبيق: $name"; return false }
            if (cands.size > 1) {
                pending = cands; pendingName = norm(name); pendingT = System.currentTimeMillis()
                val msg = "🤔 أي تطبيق تقصد؟\n" + cands.mapIndexed { i, c -> "${i + 1}) ${c.second}" }.joinToString("\n") + "\nقل: واحد أو اثنين"
                h.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
                return true
            }
            acc.launchPackage(app.first); say("✅ فتح: ${app.second}")
            return true
        }

        // ── ضغط على نص ظاهر ──
        clickRe.find(t)?.let { m ->
            val what = rest(raw, m, 4)
            if (!acc.clickByText(what)) toast("❌ ما لقيت «$what» على الشاشة") else say("👆 $what")
            return true
        }

        // ── أي نص ظاهر على الشاشة: قله فيضغط عليه ──
        if (raw.length >= 3 && acc.clickByText(raw)) { say("👆 $raw"); return true }
        return false
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "HandControl Voice", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("الأوامر الصوتية تعمل")
            .setContentText("قل: افتح [تطبيق] / اغلق [تطبيق] / التقط صورة")
            .setOngoing(true)
            .addAction(0, "إيقاف", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(2, n)
    }
}
