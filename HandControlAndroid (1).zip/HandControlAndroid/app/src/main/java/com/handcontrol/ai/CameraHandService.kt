package com.handcontrol.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** خدمة أمامية تعمل بالكاميرا الأمامية (مسموح لها بالعمل والتطبيق في الخلفية). */
class CameraHandService : LifecycleService() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.handcontrol.ai.STOP"
        private const val CH = "handcontrol"
    }

    private var landmarker: HandLandmarker? = null
    private var engine: HandEngine? = null
    private lateinit var exec: ExecutorService
    private var provider: ProcessCameraProvider? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        val acc = HandAccessibilityService.instance
        if (acc == null) { stopSelf(); return }
        val (w, h) = acc.screenSize()
        engine = HandEngine(w, h)
        exec = Executors.newSingleThreadExecutor()
        try {
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.6f)
                .setMinTrackingConfidence(0.55f)
                .build()
            landmarker = HandLandmarker.createFromOptions(this, opts)
        } catch (e: Exception) { stopSelf(); return }
        running = true
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(exec) { img ->
                try {
                    val bmp = img.toBitmap()
                    val m = Matrix().apply {
                        postRotate(img.imageInfo.rotationDegrees.toFloat())
                        postScale(-1f, 1f)   // مرآة: يد يمينك تحرّك المؤشر لليمين
                    }
                    val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    val res = landmarker?.detectForVideo(BitmapImageBuilder(rot).build(), SystemClock.uptimeMillis())
                    val lms = res?.landmarks()
                    if (lms != null && lms.isNotEmpty()) engine?.process(lms[0]) else engine?.onLost()
                } catch (_: Exception) {
                } finally { img.close() }
            }
            try {
                provider?.unbindAll()
                provider?.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (_: Exception) { stopSelf() }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { provider?.unbindAll() } catch (_: Exception) {}
        engine?.hide()
        landmarker?.close()
        if (::exec.isInitialized) exec.shutdown()
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "HandControl", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CameraHandService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HandControl يعمل")
            .setContentText("التحكم بحركة اليد نشط — اضغط «إيقاف» للإنهاء")
            .setOngoing(true)
            .addAction(0, "إيقاف", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else startForeground(1, n)
    }
}
