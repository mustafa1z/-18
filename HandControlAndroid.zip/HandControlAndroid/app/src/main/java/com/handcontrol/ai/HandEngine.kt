package com.handcontrol.ai

import android.os.SystemClock
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * يحوّل نقاط اليد (٢١ نقطة) إلى أوامر حقيقية:
 *  ☝️ توجيه المؤشر      🤏 قرصة سريعة = نقر / قرصة + تحريك = سحب (تمرير بإصبع)
 *  👊 قبضة + تحريك لأعلى/أسفل = تمرير   ✌️ رجوع    👍 الشاشة الرئيسية
 *  ✋ كف مفتوح = إيقاف مؤقت (المؤشر يتجمد)
 */
class HandEngine(private val w: Int, private val h: Int) {

    var gain = 1.6f
    var smooth = 0.5f

    private var curX = w / 2f; private var curY = h / 2f
    private var tgtX = curX; private var tgtY = curY

    private var gesture = "none"; private var cand = "none"; private var candN = 0
    private var pinchOn = false
    private var pressed = false; private var pressT = 0L
    private var pressX = 0f; private var pressY = 0f; private var moved = 0f
    private var lastWristY = 0f; private var scrollAcc = 0f; private var lastScrollT = 0L
    private var lastSeen = 0L; private var hadHand = false
    private var lastSys = 0L

    private fun svc() = HandAccessibilityService.instance

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark): Float {
        val dx = a.x() - b.x(); val dy = a.y() - b.y(); val dz = (a.z() - b.z()) * 0.5f
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun classify(lm: List<NormalizedLandmark>): String {
        val span = d(lm[0], lm[9]).coerceAtLeast(1e-6f)
        fun ext(t: Int, p: Int) = d(lm[0], lm[t]) > d(lm[0], lm[p]) * 1.18f
        val i = ext(8, 6); val m = ext(12, 10); val r = ext(16, 14); val p = ext(20, 18)
        val n = listOf(i, m, r, p).count { it }
        if (pinchOn && (i || n <= 1)) return "pinch"
        if (n == 0) {
            val thumbUp = lm[4].y() < lm[0].y() - span * 0.55f &&
                d(lm[4], lm[17]) > d(lm[3], lm[17]) * 1.05f
            return if (thumbUp) "thumb" else "fist"
        }
        if (i && !m && !r && !p) return "point"
        if (i && m && !r && !p) return "peace"
        if (n >= 4) return "palm"
        return "other"
    }

    private fun updateTarget(lm: List<NormalizedLandmark>) {
        val nx = lm[8].x(); val ny = lm[8].y()
        tgtX = (0.5f + (nx - 0.5f) * gain).coerceIn(0.015f, 0.985f) * w
        tgtY = (0.40f + (ny - 0.40f) * gain).coerceIn(0.015f, 0.985f) * h
    }

    private fun stepCursor() {
        val a = 0.65f - 0.6f * smooth
        curX += (tgtX - curX) * a; curY += (tgtY - curY) * a
    }

    private fun show(idle: Boolean = false) {
        svc()?.setCursor(curX, curY, true, idle, pressed)
    }

    @Synchronized
    fun process(lm: List<NormalizedLandmark>) {
        val now = SystemClock.uptimeMillis()
        lastSeen = now; hadHand = true

        val span = d(lm[0], lm[9]).coerceAtLeast(1e-6f)
        val pr = d(lm[4], lm[8]) / span
        if (!pinchOn && pr < 0.45f) pinchOn = true else if (pinchOn && pr > 0.62f) pinchOn = false

        val raw = classify(lm)
        if (raw == cand) candN++ else { cand = raw; candN = 1 }
        val need = if (raw == "pinch" || gesture == "pinch") 2 else 3
        if (candN >= need && gesture != raw) apply(raw, lm, now)

        when (gesture) {
            "point", "pinch" -> {
                updateTarget(lm); stepCursor()
                show()
            }
            "fist" -> {
                val dy = lm[0].y() - lastWristY; lastWristY = lm[0].y()
                scrollAcc += dy
                if (abs(scrollAcc) > 0.05f && now - lastScrollT > 300) {
                    val x = w / 2f
                    if (scrollAcc > 0) svc()?.swipe(x, h * 0.68f, x, h * 0.32f, 220)
                    else svc()?.swipe(x, h * 0.32f, x, h * 0.68f, 220)
                    scrollAcc = 0f; lastScrollT = now
                }
                show(idle = true)
            }
            "palm" -> show(idle = true)
            else -> show(idle = true)
        }
    }

    private fun apply(g: String, lm: List<NormalizedLandmark>, now: Long) {
        val prev = gesture; gesture = g
        if (prev == "pinch" && g != "pinch") release(now)
        when (g) {
            "point", "pinch" -> {
                updateTarget(lm)
                if (g == "pinch" && prev != "pinch") pressStart(now)
            }
            "fist" -> { lastWristY = lm[0].y(); scrollAcc = 0f }
            "peace" -> if (now - lastSys > 900) { lastSys = now; svc()?.back() }
            "thumb" -> if (now - lastSys > 900) { lastSys = now; svc()?.home() }
        }
    }

    private fun pressStart(now: Long) {
        pressed = true; pressT = now; pressX = curX; pressY = curY
    }

    private fun release(now: Long) {
        if (!pressed) return
        pressed = false
        val dur = now - pressT
        val dist = hypot(curX - pressX, curY - pressY)
        if (dist >= 45f) {
            svc()?.swipe(pressX, pressY, curX, curY, dur.coerceIn(150, 700))
        } else if (dur < 700) {
            svc()?.tap(pressX, pressY)
        }
    }

    @Synchronized
    fun onLost() {
        if (!hadHand) return
        val now = SystemClock.uptimeMillis()
        if (pressed && now - lastSeen > 400) pressed = false
        if (now - lastSeen > 700) {
            hadHand = false; pinchOn = false; gesture = "none"; cand = "none"
            svc()?.setCursor(curX, curY, false, false, false)
        }
    }

    fun hide() { svc()?.setCursor(curX, curY, false, false, false) }
}
