package com.handcontrol.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.core.app.NotificationCompat

/** أوامر صوتية بالعربي: «افتح واتساب»، «يمين»، «يسار»، «رجوع»، «اضغط على ...» */
class VoiceService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.handcontrol.ai.VSTOP"
        private const val CH = "handcontrol_voice"
    }

    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("⚠️ خدمة التعرف على الصوت غير متوفرة في هاتفك"); stopSelf(); return
        }
        running = true
        toast("🎤 الأوامر الصوتية تعمل — قل: افتح واتساب")
        h.post { listen() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        super.onDestroy()
    }

    private fun toast(t: String) = h.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() }

    private fun listen() {
        if (!running) return
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this)
            rec?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                    for (t in list) { if (handle(t)) break }
                    h.postDelayed({ listen() }, 250)
                }
                override fun onError(e: Int) {
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-IQ")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { rec?.startListening(i) } catch (_: Exception) { h.postDelayed({ listen() }, 800) }
    }

    // ───────────── تحليل الأمر ─────────────
    private fun norm(s: String) = s.lowercase()
        .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه').trim()

    private val openRe = Regex("^(افتح|افتحي|افتحلي|شغل|روح|اطلع|open)(\\s+(على|علي|الى|إلى|لي))?\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val clickRe = Regex("^(اضغط|انقر|كبس|دوس)(\\s+(على|علي))?\\s+(.+)$")

    private fun has(t: String, vararg w: String) = w.any { t == norm(it) || t.split(" ").contains(norm(it)) }

    private fun handle(text: String): Boolean {
        val acc = HandAccessibilityService.instance ?: return false
        val raw = text.trim()
        val t = norm(raw)
        if (t.isEmpty()) return false

        openRe.find(raw)?.let {
            val name = it.groupValues[4]
            toast("🎤 $raw")
            if (!openApp(acc, name)) toast("❌ ما لقيت تطبيق: $name")
            return true
        }
        clickRe.find(raw)?.let {
            val what = it.groupValues[4]
            toast("🎤 $raw")
            if (!acc.clickByText(what)) toast("❌ ما لقيت «$what» على الشاشة")
            return true
        }
        when {
            has(t, "رجوع", "ارجع", "للخلف", "back") -> { acc.back(); toast("🎤 رجوع") }
            has(t, "رئيسيه", "الرئيسيه", "البيت", "هوم", "home") -> { acc.home(); toast("🎤 الرئيسية") }
            has(t, "الاخيره", "اخيره", "recents") -> { acc.recents(); toast("🎤 التطبيقات الأخيرة") }
            has(t, "يمين", "لليمين", "right") -> { acc.swipeDir("right"); toast("🎤 يمين ➡️") }
            has(t, "يسار", "لليسار", "left") -> { acc.swipeDir("left"); toast("🎤 يسار ⬅️") }
            has(t, "فوق", "لفوق", "اعلي", "اعلا", "اطلع", "up") -> { acc.swipeDir("up"); toast("🎤 فوق ⬆️") }
            has(t, "تحت", "لتحت", "اسفل", "انزل", "down") -> { acc.swipeDir("down"); toast("🎤 تحت ⬇️") }
            has(t, "ايقاف", "وقف", "اوقف", "stop") -> { toast("🎤 تم إيقاف الأوامر الصوتية"); stopSelf() }
            else -> return false
        }
        return true
    }

    // اسم عربي ← كلمات تُطابق اسم الحزمة أو اسم التطبيق
    private val aliases = listOf(
        listOf("واتساب", "واتس اب", "واتس", "وتساب") to listOf("whatsapp"),
        listOf("يوتيوب", "يوتوب") to listOf("youtube"),
        listOf("تلكرام", "تليجرام", "تلغرام") to listOf("telegram"),
        listOf("انستا", "انستغرام", "انستقرام", "انستجرام") to listOf("instagram"),
        listOf("فيسبوك", "فيس بوك", "فيس") to listOf("com.facebook.katana"),
        listOf("ماسنجر", "ماسنجر") to listOf("com.facebook.orca"),
        listOf("تيك توك", "تيكتوك") to listOf("musically", "trill", "tiktok"),
        listOf("كاميرا") to listOf("camera"),
        listOf("اعدادات", "الاعدادات", "الاعدادات") to listOf("com.android.settings"),
        listOf("كروم", "متصفح", "المتصفح") to listOf("com.android.chrome"),
        listOf("صور", "الصور", "معرض", "المعرض") to listOf("gallery", "photos"),
        listOf("هاتف", "اتصال", "اتصالات", "الهاتف") to listOf("dialer", "com.android.phone"),
        listOf("رسائل", "الرسائل") to listOf("messaging", "mms"),
        listOf("حاسبه", "الحاسبه", "اله حاسبه") to listOf("calculator"),
        listOf("خرائط", "الخرائط") to listOf("com.google.android.apps.maps"),
        listOf("ساعه", "الساعه", "منبه", "المنبه") to listOf("deskclock", "clock"),
        listOf("سناب", "سنابشات", "سناب شات") to listOf("snapchat"),
        listOf("جيميل", "بريد") to listOf("com.google.android.gm"),
        listOf("متجر", "بلاي ستور", "جوجل بلاي", "المتجر") to listOf("com.android.vending"),
        listOf("سبوتيفاي") to listOf("spotify"),
        listOf("فايبر") to listOf("viber"),
        listOf("نتفلكس") to listOf("netflix"),
        listOf("تويتر", "اكس") to listOf("com.twitter")
    )

    private fun openApp(acc: HandAccessibilityService, spokenRaw: String): Boolean {
        val spoken = norm(spokenRaw)
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        // ١) بالأسماء المعروفة
        for ((names, keys) in aliases) {
            if (names.any { val n = norm(it); spoken == n || spoken.contains(n) }) {
                val hit = apps.firstOrNull { (pkg, label) ->
                    keys.any { k -> pkg.lowercase().contains(k) || label.lowercase().contains(k) }
                }
                if (hit != null) return acc.launchPackage(hit.first)
            }
        }
        // ٢) مطابقة مباشرة مع اسم التطبيق كما هو على الهاتف
        val hit = apps.firstOrNull { (_, label) ->
            val l = norm(label); l.isNotEmpty() && (l == spoken || l.contains(spoken) || spoken.contains(l))
        }
        return hit != null && acc.launchPackage(hit.first)
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "HandControl Voice", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("الأوامر الصوتية تعمل")
            .setContentText("قل: افتح واتساب / يمين / يسار / رجوع")
            .setOngoing(true)
            .addAction(0, "إيقاف", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(2, n)
    }
}
